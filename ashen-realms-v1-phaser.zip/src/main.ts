import Phaser from 'phaser';
const W=28,H=28,TW=88,TH=44;
const iso=(x:number,y:number)=>({x:(x-y)*TW/2,y:(x+y)*TH/2});
const fromScreen=(x:number,y:number)=>({x:y/TH+x/TW,y:y/TH-x/TW});
const hud=document.getElementById('hud')!,msg=document.getElementById('msg')!;
let noticeTimer=0;function say(s:string){msg.textContent=s;clearTimeout(noticeTimer);noticeTimer=window.setTimeout(()=>msg.textContent='',4500)}
type Wolf={x:number,y:number,hp:number,alive:boolean,respawn:number,shape:Phaser.GameObjects.Container,aggro:number};
class World extends Phaser.Scene{
  hero!:Phaser.GameObjects.Container; player={x:13,y:13,hp:100,maxHp:100,xp:0,level:1,gold:0,kills:0,herbs:0};
  keys!:Record<string,Phaser.Input.Keyboard.Key>; target:{x:number,y:number}|null=null; wolves:Wolf[]=[];
  joystick={x:0,y:0}; npc={x:11,y:11}; inventoryOpen=false; questDone=false; grass!:Phaser.GameObjects.Graphics;
  obstacles=new Set<string>(); lastAttack=0; lastHit=0; inv!:Phaser.GameObjects.Text; quest!:Phaser.GameObjects.Text;
  constructor(){super('world')}
  create(){this.cameras.main.setBackgroundColor('#182c30');this.grass=this.add.graphics();
    for(let y=0;y<H;y++)for(let x=0;x<W;x++){let v=Phaser.Math.Between(0,10);let p=iso(x,y);this.grass.fillStyle(v<2?0x365b45:v<5?0x426a4c:0x4b7351);this.grass.fillPoints([{x:p.x,y:p.y-TH/2},{x:p.x+TW/2,y:p.y},{x:p.x,y:p.y+TH/2},{x:p.x-TW/2,y:p.y}],true);this.grass.lineStyle(1,0x152e27,.14);this.grass.strokePoints([{x:p.x,y:p.y-TH/2},{x:p.x+TW/2,y:p.y},{x:p.x,y:p.y+TH/2},{x:p.x-TW/2,y:p.y}],true);
      if((x<8||x>18||y<8||y>18)&&v===0&&Math.random()<.65){this.obstacles.add(`${x},${y}`);this.tree(x,y)}
    }
    this.grass.setDepth(-10000);
    this.addDiamond(13,13,0x6c7565,5);this.addDiamond(11,11,0x847e65,1);
    this.makeNpc();this.hero=this.makeCharacter(13,13,0x416bd4,0xe5c3a0);this.hero.setDepth(100);
    for(const [x,y] of [[17,13],[18,16],[8,16],[17,19],[9,19],[21,11]]){const shape=this.makeWolf(x,y);this.wolves.push({x,y,hp:45,alive:true,respawn:0,shape,aggro:0})}
    this.cameras.main.startFollow(this.hero,true,.08,.08);this.cameras.main.setZoom(Math.min(1.15,Math.max(.65,window.innerWidth/1050)));
    this.keys=this.input.keyboard!.addKeys('W,A,S,D,UP,DOWN,LEFT,RIGHT,E,SPACE,I') as Record<string,Phaser.Input.Keyboard.Key>;
    this.input.on('pointerdown',(p:Phaser.Input.Pointer)=>{if(p.event.target instanceof HTMLCanvasElement){const wp=this.cameras.main.getWorldPoint(p.x,p.y);const pos=fromScreen(wp.x,wp.y);this.target={x:Phaser.Math.Clamp(pos.x,0,W-1),y:Phaser.Math.Clamp(pos.y,0,H-1)}}});
    this.inv=this.add.text(0,0,'',{fontFamily:'monospace',fontSize:'17px',color:'#f7e9c8',backgroundColor:'#14252be8',padding:{x:16,y:16}}).setScrollFactor(0).setDepth(100000).setVisible(false);
    this.quest=this.add.text(0,0,'',{fontFamily:'sans-serif',fontSize:'15px',color:'#f7e9c8',backgroundColor:'#14252bd9',padding:{x:10,y:8}}).setScrollFactor(0).setDepth(100000);
    document.getElementById('attack')!.addEventListener('pointerdown',e=>{e.preventDefault();this.attack()});document.getElementById('talk')!.addEventListener('pointerdown',e=>{e.preventDefault();this.talk()});document.getElementById('inventory')!.addEventListener('pointerdown',e=>{e.preventDefault();this.toggleInventory()});
    const joy=document.getElementById('joystick')!,stick=document.getElementById('stick')!;
    const move=(e:PointerEvent)=>{const r=joy.getBoundingClientRect(),dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2),m=Math.hypot(dx,dy),f=Math.min(1,m/42);this.joystick={x:m?dx/m*f:0,y:m?dy/m*f:0};stick.style.transform=`translate(${this.joystick.x*34}px,${this.joystick.y*34}px)`};
    joy.addEventListener('pointerdown',e=>{joy.setPointerCapture(e.pointerId);move(e)});joy.addEventListener('pointermove',e=>{if(joy.hasPointerCapture(e.pointerId))move(e)});const reset=()=>{this.joystick={x:0,y:0};stick.style.transform='translate(0,0)'};joy.addEventListener('pointerup',reset);joy.addEventListener('pointercancel',reset);
    this.scale.on('resize',()=>this.layout());this.layout();this.refreshHud();say('Vorbește cu Păzitorul din piață, apoi învinge 3 lupi!');
  }
  addDiamond(x:number,y:number,color:number,r:number){const g=this.add.graphics();g.fillStyle(color,.28);for(let a=-r;a<=r;a++)for(let b=-r;b<=r;b++){if(Math.abs(a)+Math.abs(b)>r)continue;const p=iso(x+a,y+b);g.fillPoints([{x:p.x,y:p.y-TH/2},{x:p.x+TW/2,y:p.y},{x:p.x,y:p.y+TH/2},{x:p.x-TW/2,y:p.y}],true)}g.setDepth(-9000)}
  tree(x:number,y:number){const p=iso(x,y),g=this.add.graphics();g.fillStyle(0x473629);g.fillRect(-5,-50,10,55);g.fillStyle(0x244b38);g.fillTriangle(-29,-36,0,-105,29,-36);g.fillStyle(0x316647);g.fillTriangle(-25,-54,0,-122,25,-54);g.setPosition(p.x,p.y).setDepth(p.y)}
  makeCharacter(x:number,y:number,coat:number,skin:number){const p=iso(x,y),g=this.add.graphics();g.fillStyle(0x000000,.28);g.fillEllipse(0,2,33,14);g.fillStyle(0x22292d);g.fillRect(-10,-18,8,21);g.fillRect(2,-18,8,21);g.fillStyle(coat);g.fillRoundedRect(-14,-47,28,33,6);g.fillStyle(skin);g.fillCircle(0,-55,11);g.fillStyle(0x44342a);g.fillEllipse(0,-64,22,9);g.lineStyle(4,0xd2dce2);g.lineBetween(18,-42,26,-74);return this.add.container(p.x,p.y,[g]).setDepth(p.y+5)}
  makeNpc(){const npc=this.makeCharacter(this.npc.x,this.npc.y,0x9b783b,0xf0c5a1);this.add.text(npc.x,npc.y-90,'Păzitorul',{fontSize:'15px',color:'#f8d990',backgroundColor:'#18272ac9'}).setOrigin(.5).setDepth(10000)}
  makeWolf(x:number,y:number){const p=iso(x,y),g=this.add.graphics();g.fillStyle(0x000000,.25);g.fillEllipse(0,0,39,15);g.fillStyle(0x716e65);g.fillEllipse(0,-18,43,24);g.fillTriangle(12,-25,18,-48,26,-26);g.fillTriangle(-4,-26,1,-45,8,-25);g.fillStyle(0xe5b455);g.fillCircle(15,-25,3);return this.add.container(p.x,p.y,[g]).setDepth(p.y+3)}
  canMove(x:number,y:number){return x>=1&&x<W-1&&y>=1&&y<H-1&&!this.obstacles.has(`${Math.round(x)},${Math.round(y)}`)}
  update(t:number,delta:number){const dt=Math.min(delta/1000,.05);let sx=0,sy=0;
    if(this.keys.W.isDown||this.keys.UP.isDown)sy--;if(this.keys.S.isDown||this.keys.DOWN.isDown)sy++;if(this.keys.A.isDown||this.keys.LEFT.isDown)sx--;if(this.keys.D.isDown||this.keys.RIGHT.isDown)sx++;
    if(Math.abs(this.joystick.x)+Math.abs(this.joystick.y)>.1){sx=this.joystick.x;sy=this.joystick.y}
    if(sx||sy){this.target=null;const norm=Math.max(1,Math.hypot(sx,sy));const dx=(sx/norm*2-sy/norm*2)*dt,dy=(sx/norm*2+sy/norm*2)*dt;this.step(dx,dy)}
    else if(this.target){const dx=this.target.x-this.player.x,dy=this.target.y-this.player.y,d=Math.hypot(dx,dy);if(d<.15)this.target=null;else this.step(dx/d*3.3*dt,dy/d*3.3*dt)}
    if(Phaser.Input.Keyboard.JustDown(this.keys.SPACE))this.attack();if(Phaser.Input.Keyboard.JustDown(this.keys.E))this.talk();if(Phaser.Input.Keyboard.JustDown(this.keys.I))this.toggleInventory();
    for(const w of this.wolves){if(!w.alive){if(t>w.respawn){w.alive=true;w.hp=45;w.shape.setVisible(true)}continue}const d=Math.hypot(w.x-this.player.x,w.y-this.player.y);if(d<4.5&&d>1.0){const dx=(this.player.x-w.x)/d*dt*.62,dy=(this.player.y-w.y)/d*dt*.62;if(this.canMove(w.x+dx,w.y+dy)){w.x+=dx;w.y+=dy}}if(d<1.3&&t-w.aggro>1450){w.aggro=t;this.player.hp=Math.max(0,this.player.hp-8);this.refreshHud();if(this.player.hp===0){this.player.hp=this.player.maxHp;this.player.x=13;this.player.y=13;this.player.gold=Math.max(0,this.player.gold-5);say('Ai fost învins! Te-ai întors în oraș.')}}const p=iso(w.x,w.y);w.shape.setPosition(p.x,p.y).setDepth(p.y+3)}
    const p=iso(this.player.x,this.player.y);this.hero.setPosition(p.x,p.y).setDepth(p.y+5);
  }
  step(dx:number,dy:number){if(this.canMove(this.player.x+dx,this.player.y))this.player.x+=dx;if(this.canMove(this.player.x,this.player.y+dy))this.player.y+=dy}
  attack(){const t=this.time.now;if(t-this.lastAttack<450)return;this.lastAttack=t;const near=this.wolves.filter(w=>w.alive&&Math.hypot(w.x-this.player.x,w.y-this.player.y)<2.15).sort((a,b)=>Math.hypot(a.x-this.player.x,a.y-this.player.y)-Math.hypot(b.x-this.player.x,b.y-this.player.y))[0];const p=iso(this.player.x,this.player.y);const flash=this.add.circle(p.x,p.y-25,60,0xe9ca75,.32).setDepth(p.y+6);this.tweens.add({targets:flash,alpha:0,scale:1.4,duration:230,onComplete:()=>flash.destroy()});if(!near){say('Apropie-te de un lup ca să ataci.');return}near.hp-=25;if(near.hp<=0){near.alive=false;near.shape.setVisible(false);near.respawn=t+12000;this.player.kills++;this.player.xp+=25;this.player.gold+=7;this.player.herbs++;if(this.player.xp>=this.player.level*100){this.player.xp-=this.player.level*100;this.player.level++;this.player.maxHp+=15;this.player.hp=this.player.maxHp;say(`Nivel nou! Nivel ${this.player.level}`)}else say('Lup învins! +25 XP, +7 gold, +1 plantă.');this.refreshHud()}else say(`Lovitură! Lupul mai are ${near.hp} HP.`)}
  talk(){const d=Math.hypot(this.player.x-this.npc.x,this.player.y-this.npc.y);if(d>2.2){say('Apropie-te de Păzitorul din piață.');return}if(this.questDone){say('Păzitorul: Satul îți mulțumește, aventurierule!');return}if(this.player.kills>=3){this.questDone=true;this.player.gold+=50;this.player.xp+=50;say('Quest finalizat! Recompensă: 50 gold și 50 XP.');this.refreshHud()}else say(`Păzitorul: Învinge 3 lupi! Progres ${this.player.kills}/3.`)}
  toggleInventory(){this.inventoryOpen=!this.inventoryOpen;this.inv.setVisible(this.inventoryOpen);this.layout()}
  layout(){const w=this.scale.width,h=this.scale.height;this.quest.setPosition(Math.max(10,w-245),65);this.quest.setText(`MISIUNE: 3 lupi\n${Math.min(3,this.player.kills)}/3 învinși\n${this.questDone?'✓ Completată':'Revino la Păzitor'}`);this.inv.setPosition(Math.max(12,w/2-150),Math.max(85,h/2-100));this.inv.setText(`INVENTAR\n─────────────\n🪙 Gold: ${this.player.gold}\n🌿 Plante: ${this.player.herbs}\n⚔️ Sabie de început\n🛡️ Tunică de novice\n\nApasă BAG sau I`)}
  refreshHud(){hud.innerHTML=`<strong>⚔ ASHEN REALMS · V1</strong><br/>Nivel ${this.player.level} · HP ${this.player.hp}/${this.player.maxHp}<br/>XP ${this.player.xp}/${this.player.level*100} · 🪙 ${this.player.gold} gold<br/>Lupi învinși: ${this.player.kills}`;if(this.inv)this.layout()}
}
new Phaser.Game({type:Phaser.AUTO,parent:'app',backgroundColor:'#182c30',scale:{mode:Phaser.Scale.RESIZE,width:window.innerWidth,height:window.innerHeight,autoCenter:Phaser.Scale.CENTER_BOTH},render:{pixelArt:false,antialias:true},scene:[World]});
