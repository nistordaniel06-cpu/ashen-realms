# Ashen Realms V1

Prototype RPG fantasy 2.5D izometric, Phaser 3 + TypeScript + Vite. **Single-player, fără server sau autentificare.**

## Start

```bash
npm install
npm run dev
```

Deschide adresa Vite din terminal (pe telefon în aceeași rețea, folosește IP-ul calculatorului și portul 5173).

## Build

```bash
npm run build
```

Publică folderul `dist/` pe un hosting static (Vercel/Pages).

## Control

- PC: WASD/săgeți, click pe hartă, Space atac, E dialog, I inventar.
- Mobil: joystick stânga, butoane ATAC / NPC / BAG dreapta.
- Quest: învinge 3 lupi, apoi vorbește cu Păzitorul în piață.

## Ce există

Hartă izometrică generată procedural, copaci și coliziuni, cameră urmăritoare, erou, NPC, lupi cu aggro, atac, HP, XP, nivel, gold, inventar și quest.

## Limitări

Grafica este desenată procedural, nu sprites profesionale; nu există salvare, sunet, multiplayer, conturi, server autoritar sau panou GM. Acestea sunt etape ulterioare.
